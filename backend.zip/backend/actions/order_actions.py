from repository.database import insert_order

# class OrdersActions:

# 	def __init__(self) -> None:
# 		self.order_repo = OrderRepository()

# def insert_orders(order):
# 	try:
# 		item = insert_order(order)
# 		return item
# 	except Exception as e:
# 		print(e)
# 		return {}
